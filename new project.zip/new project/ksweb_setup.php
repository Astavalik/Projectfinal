<?php
// File: ksweb_setup.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// KSWEB Specific Configuration
$host = 'localhost';
$username = 'root';     // KSWEB default
$password = 'root';     // KSWEB default
$dbname = 'admin_management_system';

try {
    // Connect to MySQL
    $conn = new PDO("mysql:host=$host", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Create database
    $conn->exec("CREATE DATABASE IF NOT EXISTS $dbname");
    $conn->exec("USE $dbname");

    // Create users table with more robust schema
    $conn->exec("DROP TABLE IF EXISTS users");
    $conn->exec("CREATE TABLE users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        surname VARCHAR(50) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('user', 'admin', 'super_admin') DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Generate SECURE initial credentials
    $username = 'admin';
    $email = 'admin@ksweb.local';
    
    // Use a more complex initial password
    $password = password_hash('KSWeb2024!Admin', PASSWORD_BCRYPT);

    // Insert super admin
    $stmt = $conn->prepare("INSERT INTO users 
        (username, email, password, name, surname, role) 
        VALUES (:username, :email, :password, 'System', 'Administrator', 'super_admin')");
    
    $stmt->execute([
        ':username' => $username,
        ':email' => $email,
        ':password' => $password
    ]);

    echo "<h2 style='color:green'>Setup Successful!</h2>";
    echo "Login Credentials:<br>";
    echo "Username: admin<br>";
    echo "Password: KSWeb2024!Admin<br>";

} catch(PDOException $e) {
    echo "<h2 style='color:red'>Setup Error</h2>";
    echo "Error: " . $e->getMessage();
}
?>