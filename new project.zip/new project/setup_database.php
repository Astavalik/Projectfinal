<?php
// File: setup_database.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection details
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'admin_management_system';

try {
    // Connect to MySQL without selecting a database
    $conn = new PDO("mysql:host=$host", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // Create database
    $conn->exec("CREATE DATABASE IF NOT EXISTS $dbname");
    $conn->exec("USE $dbname");

    // Create users table
    $conn->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        surname VARCHAR(50) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('user', 'admin', 'super_admin') DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Check if super admin exists
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE role = 'super_admin'");
    $stmt->execute();
    $adminCount = $stmt->fetchColumn();

    // Create super admin if not exists
    if ($adminCount == 0) {
        $username = 'superadmin';
        $email = 'admin@system.com';
        $password = password_hash('AdminPass123!', PASSWORD_BCRYPT);

        $insert = $conn->prepare("INSERT INTO users 
            (username, email, password, name, surname, role) 
            VALUES (:username, :email, :password, 'System', 'Administrator', 'super_admin')");
        
        $insert->execute([
            ':username' => $username,
            ':email' => $email,
            ':password' => $password
        ]);

        echo "<div style='color:green;'>";
        echo "Super Admin Created:<br>";
        echo "Username: superadmin<br>";
        echo "Password: AdminPass123!<br>";
        echo "IMPORTANT: Change this password immediately!";
        echo "</div>";
    }

    echo "<div style='color:green;'>Database setup completed successfully!</div>";

} catch(PDOException $e) {
    echo "<div style='color:red;'>Setup Error: " . $e->getMessage() . "</div>";
}
?>