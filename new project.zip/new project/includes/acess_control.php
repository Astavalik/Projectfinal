<?php
// File: includes/access_control.php
function checkAccess($requiredRole) {
    session_start();
    
    // Redirect to login if not authenticated
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    // Role hierarchy
    $roleHierarchy = [
        'user' => 1,
        'admin' => 2,
        'super_admin' => 3
    ];

    // Check if current user has sufficient role
    $currentRole = $_SESSION['role'] ?? 'user';
    
    if (!isset($roleHierarchy[$currentRole]) || 
        !isset($roleHierarchy[$requiredRole]) || 
        $roleHierarchy[$currentRole] < $roleHierarchy[$requiredRole]) {
        
        // Insufficient privileges
        header("Location: insufficient_access.php");
        exit();
    }
}

// Optional: Create an insufficient access page
function createInsufficientAccessPage() {
    // File: insufficient_access.php
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Insufficient Access</title>
        <style>
            body { 
                font-family: Arial, sans-serif; 
                text-align: center; 
                padding: 50px; 
            }
            .error { 
                color: red; 
                font-size: 24px; 
            }
        </style>
    </head>
    <body>
        <div class="error">
            <h1>Access Denied</h1>
            <p>You do not have sufficient privileges to access this page.</p>
            <a href="login.php">Return to Login</a>
        </div>
    </body>
    </html>
    <?php
    exit();
}
?>