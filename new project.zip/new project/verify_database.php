<?php
// File: verify_database.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Database connection details
    $host = 'localhost';
    $username = 'root';  // Confirm KSWEB default username
    $password = 'root';  // Confirm KSWEB default password
    $dbname = 'admin_management_system';

    // Create connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check users table
    $stmt = $conn->query("SELECT * FROM users");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "<h2>Database Users:</h2>";
    foreach ($users as $user) {
        echo "Username: " . htmlspecialchars($user['username']) . 
             " | Role: " . htmlspecialchars($user['role']) . "<br>";
    }

} catch(PDOException $e) {
    echo "Connection Error: " . $e->getMessage() . "<br>";
    echo "Possible issues:<br>";
    echo "1. MySQL not running<br>";
    echo "2. Incorrect username/password<br>";
    echo "3. Database not created<br>";
}
?>