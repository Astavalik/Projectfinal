<?php
// File: add_user.php
require_once 'includes/access_control.php';
checkAccess('super_admin');

require_once 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $conn = $database->getConnection();

    try {
        // Validate input
        $name = trim($_POST['name']);
        $surname = trim($_POST['surname']);
        $email = trim($_POST['email']);
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        $role = $_POST['role'];

        // Basic validation
        if (empty($name) || empty($email) || empty($username) || empty($password)) {
            throw new Exception("All fields are required");
        }

        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Prepare and execute insert
        $stmt = $conn->prepare("INSERT INTO users 
            (name, surname, email, username, password, role) 
            VALUES (:name, :surname, :email, :username, :password, :role)");
        
        $stmt->execute([
            ':name' => $name,
            ':surname' => $surname,
            ':email' => $email,
            ':username' => $username,
            ':password' => $hashedPassword,
            ':role' => $role
        ]);

        // Redirect with success message
        header("Location: dashboard_super_admin.php?success=1");
        exit();

    } catch(PDOException $e) {
        // Handle duplicate entries
        if ($e->getCode() == '23000') {
            header("Location: dashboard_super_admin.php?error=Username or email already exists");
        } else {
            header("Location: dashboard_super_admin.php?error=" . urlencode($e->getMessage()));
        }
        exit();
    } catch(Exception $e) {
        header("Location: dashboard_super_admin.php?error=" . urlencode($e->getMessage()));
        exit();
    }
} else {
    // Direct access prevention
    header("Location: dashboard_super_admin.php");
    exit();
}
?>